export default function Home() {
  return <div>Home — go to <a href="/gallery">/gallery</a></div>;
}
