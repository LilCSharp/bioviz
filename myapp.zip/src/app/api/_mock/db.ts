// app/api/_mock/db.ts
// Dev-only in-memory DB used by route handlers

export type Id = string;

// ---- API-facing shapes (what routes return) ----
export type FolderRef = {
  id: Id;
  type: 'folder';
  name: string;
  path: string[];                 // ancestry names, e.g., ["Gallery", "Trips", "Paris"]
  createdAt: string;
  updatedAt: string;
  counts?: { images: number; folders: number; total: number };
  previewImageUrl?: string;       // first image under this folder (if any)
};

export type ImageRef = {
  id: Id;
  type: 'image';
  name: string;
  path: string[];                 // ancestry names
  createdAt: string;
  sizeBytes: number;
  mime: string;
  width: number;
  height: number;
  thumbnailUrl: string;
  originalUrl: string;
};

export type GalleryItem = FolderRef | ImageRef;

export type SplatRef = {
  id: Id;
  name: string;
  createdAt: string;
  updatedAt: string;
  status: 'ready' | 'processing' | 'failed';
  previewImageUrl?: string;
  assetUrl?: string;
};

export type JobRef = {
  id: Id;
  createdAt: string;
  status: 'queued' | 'running' | 'failed' | 'completed';
  progress?: { pct: number; detail?: string };
  selectionSnapshot?: { imageIds: Id[]; folderIds: Id[] };
  resultSplatId?: Id;
  error?: string;
};

// ---- internal nodes (contain children/parentId) ----
type FolderNode = {
  id: Id;
  name: string;
  parentId?: Id;
  children: Id[];                 // mix of folder & image ids
  createdAt: string;
  updatedAt: string;
};

type ImageNode = {
  id: Id;
  name: string;
  parentId: Id;
  createdAt: string;
  sizeBytes: number;
  mime: string;
  width: number;
  height: number;
};

const now = () => new Date().toISOString();
const rnd = (n = 6) =>
  Array.from({ length: n }, () => 'abcdefghijklmnopqrstuvwxyz0123456789'[Math.floor(Math.random() * 36)]).join('');

export class MockDB {
  folders = new Map<Id, FolderNode>();
  images = new Map<Id, ImageNode>();
  splats = new Map<Id, SplatRef>();
  jobs = new Map<Id, JobRef>();

  rootId: Id = 'root';

  constructor() {
    if (!this.folders.size) this.seed();
  }

  private mkFolder(name: string, parentId?: Id) {
    const id = `${name.toLowerCase().replace(/\s+/g, '-')}-${rnd(4)}`;
    const node: FolderNode = { id, name, parentId, children: [], createdAt: now(), updatedAt: now() };
    this.folders.set(id, node);
    if (parentId) this.folders.get(parentId)!.children.push(id);
    return id;
  }

  private mkImage(name: string, parentId: Id) {
    const id = `${name.toLowerCase().replace(/\s+/g, '-')}-${rnd(5)}`;
    const createdAt = new Date(Date.now() - Math.floor(Math.random() * 10) * 86_400_000).toISOString();
    const node: ImageNode = {
      id, name, parentId, createdAt,
      sizeBytes: 500_000 + Math.floor(Math.random() * 3_000_000),
      mime: 'image/jpeg', width: 1600, height: 900,
    };
    this.images.set(id, node);
    this.folders.get(parentId)!.children.push(id);
    return id;
  }

  seed() {
    // root
    this.folders.set(this.rootId, { id: this.rootId, name: 'Gallery', parentId: undefined, children: [], createdAt: now(), updatedAt: now() });

    // folders
    const trips = this.mkFolder('Trips', this.rootId);
    const paris = this.mkFolder('Paris 2025', trips);
    const day1  = this.mkFolder('Day 1', paris);
    const day2  = this.mkFolder('Day 2', paris);
    const lab   = this.mkFolder('Lab', this.rootId);

    // images
    for (let i = 1; i <= 8; i++) this.mkImage(`Eiffel_${i}.jpg`, day1);
    for (let i = 1; i <= 6; i++) this.mkImage(`Louvre_${i}.jpg`, day2);
    for (let i = 1; i <= 7; i++) this.mkImage(`Microscope_${i}.jpg`, lab);

    // splats
    this.splats.set('splat-1', {
      id: 'splat-1', name: 'Paris Courtyard', createdAt: now(), updatedAt: now(),
      status: 'ready', previewImageUrl: '/placeholder.png', assetUrl: 'https://example.com/assets/splat1.splat',
    });
    this.splats.set('splat-2', {
      id: 'splat-2', name: 'Lab Bench', createdAt: new Date(Date.now() - 86_400_000).toISOString(), updatedAt: now(),
      status: 'processing', previewImageUrl: '/placeholder.png',
    });
  }

  // ---------- helpers ----------
  getPathNames(folderId?: Id): string[] {
    if (!folderId || folderId === this.rootId) return ['Gallery'];
    const names: string[] = [];
    let cur: Id | undefined = folderId;
    while (cur) {
      const f = this.folders.get(cur);
      if (!f) break;
      names.push(f.name);
      cur = f.parentId;
    }
    names.push('Gallery');
    return names.reverse();
  }

  countDescendants(folderId: Id) {
    let images = 0, folders = 0;
    const stack: Id[] = [folderId];
    while (stack.length) {
      const id = stack.pop()!;
      const f = this.folders.get(id)!;
      for (const cid of f.children) {
        if (this.folders.has(cid)) { folders++; stack.push(cid); }
        else if (this.images.has(cid)) { images++; }
      }
    }
    return { images, folders };
  }

  private firstImageThumbUnder(folderId: Id): string | undefined {
    const stack: Id[] = [folderId];
    while (stack.length) {
      const id = stack.pop()!;
      const f = this.folders.get(id);
      if (!f) continue;
      for (const cid of f.children) {
        if (this.images.has(cid)) {
          return '/placeholder.png'; // real backend: use that image’s thumbnail
        } else if (this.folders.has(cid)) {
          stack.push(cid);
        }
      }
    }
    return undefined;
  }

  // ---------- API projections ----------
  listFolder(parentId?: Id): GalleryItem[] {
    const pid = parentId ?? this.rootId;
    const node = this.folders.get(pid);
    if (!node) throw new Error('Folder not found');

    return node.children.map((cid) => {
      const f = this.folders.get(cid);
      if (f) {
        const counts = this.countDescendants(cid);
        const folder: FolderRef = {
          id: f.id,
          type: 'folder',
          name: f.name,
          path: this.getPathNames(f.id),
          createdAt: f.createdAt,
          updatedAt: f.updatedAt,
          counts: { images: counts.images, folders: counts.folders, total: counts.images + counts.folders },
          previewImageUrl: this.firstImageThumbUnder(f.id),
        };
        return folder;
      }
      const im = this.images.get(cid)!;
      const image: ImageRef = {
        id: im.id,
        type: 'image',
        name: im.name,
        path: this.getPathNames(im.parentId),
        createdAt: im.createdAt,
        sizeBytes: im.sizeBytes,
        mime: im.mime,
        width: im.width,
        height: im.height,
        thumbnailUrl: '/placeholder.png',
        originalUrl: 'https://example.com/original.jpg',
      };
      return image;
    });
  }

  resolveSelection(imageIds: Id[], folderIds: Id[]) {
    const resolved = new Set<Id>(imageIds);
    for (const fid of folderIds) {
      const stack = [fid];
      while (stack.length) {
        const id = stack.pop()!;
        const f = this.folders.get(id);
        if (!f) continue;
        for (const cid of f.children) {
          if (this.folders.has(cid)) stack.push(cid);
          else if (this.images.has(cid)) resolved.add(cid);
        }
      }
    }
    return Array.from(resolved);
  }

  createJob(imageIds: Id[], folderIds: Id[], name?: string): JobRef {
    const id = `job-${rnd(5)}`;
    const job: JobRef = {
      id, createdAt: now(), status: 'queued', progress: { pct: 0, detail: 'Queued' },
      selectionSnapshot: { imageIds, folderIds },
    };
    this.jobs.set(id, job);
    return job;
  }

  getJob(jobId: Id): JobRef | undefined {
    const j = this.jobs.get(jobId);
    if (!j) return undefined;
    const age = Date.now() - new Date(j.createdAt).getTime();
    const pct = Math.min(100, Math.floor(age / 300)); // ~30s to complete
    if (pct < 5) j.status = 'queued';
    else if (pct < 99) j.status = 'running';
    else j.status = 'completed';
    j.progress = { pct: j.status === 'completed' ? 100 : pct, detail: j.status === 'running' ? 'Processing images' : (j.status === 'queued' ? 'Queued' : 'Done') };
    if (j.status === 'completed' && !j.resultSplatId) {
      const sid = `splat-${rnd(4)}`;
      this.splats.set(sid, { id: sid, name: `Scene ${sid}`, createdAt: now(), updatedAt: now(), status: 'ready', previewImageUrl: '/placeholder.png', assetUrl: `https://example.com/assets/${sid}.splat` });
      j.resultSplatId = sid;
    }
    return j;
  }

  listSplats(limit = 60) {
    const arr = Array.from(this.splats.values()).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit);
    const groups = new Map<string, SplatRef[]>();
    for (const s of arr) {
      const key = s.createdAt.slice(0, 10);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key)!.push(s);
    }
    return Array.from(groups.entries()).map(([date, items]) => ({ date, items }));
  }
}

export const db = new MockDB();
