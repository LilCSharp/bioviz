// app/api/folder/[id]/route.ts
import { NextResponse } from 'next/server';
import { db } from '../../_mock/db';

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const folder = db.folders.get(params.id);
  if (!folder) return NextResponse.json({ error: 'not found' }, { status: 404 });

  // Build ancestor chain with real IDs
  const chain = [];
  let cur: string | undefined = params.id;
  while (cur) {
    const f = db.folders.get(cur);
    if (!f) break;
    chain.push({ id: f.id, name: f.name });
    cur = f.parentId;
  }
  chain.push({ id: db.rootId, name: 'Gallery' });
  chain.reverse();

  return NextResponse.json({ path: chain });
}
