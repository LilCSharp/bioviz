import * as React from 'react';
import BreadcrumbsNav from '@/components/appbar/BreadcrumbsNav';
import UploadDropzone from '@/components/gallery/UploadDropzone';
import GalleryGrid from '@/components/gallery/GalleryGrid';
import SelectionDrawer from '@/components/selection/SelectionDrawer';
import { api } from '@/lib/api';
import { routes } from '@/lib/routes';
import type { GalleryItem } from '@/lib/types';

export const revalidate = 60;

export default async function GalleryPage({
  searchParams,
}: {
  searchParams: Promise<{ folderId?: string }>;
}) {
  const sp = await searchParams;           // ✅ unwrap the promise
  const folderId = sp.folderId;
  const data = await api<{ items: GalleryItem[]; nextCursor?: string }>(
    routes.gallery(folderId) + '&limit=40&sort=-date',
    { next: { revalidate } },
  );

  return (
    <>
      <BreadcrumbsNav />
      <UploadDropzone />
      <GalleryGrid
        initialItems={data.items}
        initialNextCursor={data.nextCursor}
        folderId={folderId}
      />
      <SelectionDrawer />
    </>
  );
}
