import * as React from 'react';
import { api } from '@/lib/api';
import { routes } from '@/lib/routes';
import ViewerCanvas from '@/components/viewer/ViewerCanvas';
import ViewerSidePanel from '@/components/viewer/ViewerSidePanel';
import type { SplatRef } from '@/lib/types';

export const revalidate = 300;

export async function generateMetadata({ params }: { params: { splatId: string } }) {
  try {
    const s = await api<SplatRef>(routes.splats.one(params.splatId), { next: { revalidate } }); // ✅
    return { title: `${s.name} — Splat` };
  } catch {
    return { title: 'Splat' };
  }
}

export default async function SplatViewer({ params }: { params: { splatId: string } }) {
  const splat = await api<SplatRef>(routes.splats.one(params.splatId), { next: { revalidate } }); // ✅
  if (splat.status !== 'ready' || !splat.assetUrl) {
    return <div>Scene not ready yet or missing asset — try again later.</div>;
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 12, height: '80vh' }}>
      <ViewerCanvas splatId={params.splatId} assetUrl={splat.assetUrl} />
      <ViewerSidePanel splatId={params.splatId} />
    </div>
  );
}
