import * as React from 'react';
import { api } from '@/lib/api';
import { routes } from '@/lib/routes';
import type { SplatRef } from '@/lib/types';

export const revalidate = 60;

type Group = { date: string; items: SplatRef[] };

export default async function SplatsPage() {
  const data = await api<{ groups: Group[]; nextCursor?: string }>(
    routes.splats.list + '?limit=60',
    { next: { revalidate } },   // ✅ no cast
  );

  return (
    <div>
      {data.groups.map((g) => (
        <section key={g.date}>
          <h3>{g.date}</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(220px,1fr))', gap: 12 }}>
            {g.items.map((s) => (
              <a key={s.id} href={`/splats/${s.id}`} style={{ border: '1px solid #ddd', padding: 8 }}>
                <img src={s.previewImageUrl || '/placeholder.png'} alt={s.name} style={{ width: '100%' }} />
                <div>{s.name}</div>
                <small>{new Date(s.createdAt).toLocaleString()}</small>
              </a>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
