const withParams = (base: string, params: Record<string, string | number | undefined>) => {
  const q = Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== '')
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`)
    .join('&');
  return q ? `${base}?${q}` : base;
};

export const routes = {
  gallery: (parentId?: string) => withParams('/api/gallery', { parentId, sort: '-date' }),
  folder: (id: string) => `/api/folder/${id}`,
  uploads: { presign: `/api/uploads/presign`, commit: `/api/uploads/commit` },
  selection: { resolve: `/api/selection/resolve` },
  jobs: { create: `/api/gs/jobs`, status: (id: string) => `/api/gs/jobs/${id}` },
  splats: { list: `/api/gs/splats`, one: (id: string) => `/api/gs/splats/${id}` },
};
