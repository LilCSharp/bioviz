'use client';
import createCache from '@emotion/cache';
export const muiCache = () => createCache({ key: 'mui', prepend: true });
