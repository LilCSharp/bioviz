'use client';
import * as React from 'react';
import {
  Card, CardActionArea, CardContent, CardMedia, Checkbox, Chip, Box, Typography, Stack, Tooltip,
} from '@mui/material';
import FolderIcon from '@mui/icons-material/Folder';
import ImageIcon from '@mui/icons-material/Image';
import { useNav } from '@/lib/nav';
import type { GalleryItem } from '@/lib/types';

type Props = {
  item: GalleryItem;
  onToggleSelect?: (id: string, kind: 'image'|'folder') => void;
  selected?: boolean;
};

export default function GalleryItemCard({ item, onToggleSelect, selected }: Props) {
  const { goGallery } = useNav();

  const isFolder = item.type === 'folder';
  const title = item.name;

  // Media source
  const mediaSrc = isFolder
    ? (item.previewImageUrl ?? undefined)
    : (item.thumbnailUrl);

  // Click behavior: open folder or (later) open preview
  const handleOpen = () => {
    if (isFolder) goGallery(item.id);
    // else: open image preview dialog (future)
  };

  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleSelect?.(item.id, item.type);
  };

  return (
    <Card variant="outlined" sx={{ borderRadius: 2, overflow: 'hidden' }}>
      <CardActionArea onClick={handleOpen} sx={{ alignItems: 'stretch' }}>
        {/* Media area with 3:2 aspect ratio */}
        <Box sx={{ position: 'relative', pt: '66.666%' /* 3:2 */ }}>
          {mediaSrc ? (
            <CardMedia
              component="img"
              src={mediaSrc}
              alt={title}
              sx={{
                position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover',
              }}
              loading="lazy"
            />
          ) : (
            <Box
              sx={{
                position: 'absolute', inset: 0, display: 'grid', placeItems: 'center',
                bgcolor: 'action.hover',
              }}
            >
              {isFolder ? <FolderIcon fontSize="large" /> : <ImageIcon fontSize="large" />}
            </Box>
          )}

          {/* Top-left type chip */}
          <Box sx={{ position: 'absolute', top: 8, left: 8 }}>
            <Chip
              size="small"
              label={isFolder ? 'Folder' : 'Image'}
              color={isFolder ? 'default' : 'primary'}
              sx={{ bgcolor: isFolder ? 'background.paper' : undefined }}
            />
          </Box>

          {/* Top-right checkbox */}
          <Box sx={{ position: 'absolute', top: 4, right: 4 }}>
            <Tooltip title={selected ? 'Deselect' : 'Select'}>
              <Checkbox
                size="small"
                checked={Boolean(selected)}
                onClick={handleToggle}
                sx={{
                  bgcolor: 'rgba(0,0,0,0.2)',
                  borderRadius: 1,
                  '& .MuiSvgIcon-root': { fontSize: 20 },
                }}
              />
            </Tooltip>
          </Box>
        </Box>

        {/* Caption */}
        <CardContent sx={{ py: 1.25 }}>
          <Stack direction="row" alignItems="center" spacing={1} overflow="hidden">
            <Typography variant="body2" noWrap title={title} sx={{ flex: 1 }}>
              {title}
            </Typography>
            {/* Folder counts (if available) */}
            {isFolder && item.counts?.images ? (
              <Typography variant="caption" color="text.secondary">
                {item.counts.images} img{item.counts.images === 1 ? '' : 's'}
              </Typography>
            ) : null}
          </Stack>
        </CardContent>
      </CardActionArea>
    </Card>
  );
}
