// components/gallery/GalleryGrid.tsx
'use client';
import * as React from 'react';
import Grid from '@mui/material/Grid';  // v6 Grid2
import type { GalleryItem } from '@/lib/types';
import { useInfiniteGallery } from '@/hooks/useInfiniteGallery';
import { usePersistScroll } from '@/hooks/usePersistScroll';
import GalleryItemCard from './GalleryItemCard';

type Props = {
  initialItems: GalleryItem[];
  initialNextCursor?: string;
  folderId?: string;
};

export default function GalleryGrid({ initialItems, initialNextCursor, folderId }: Props) {
  usePersistScroll(`gallery:${folderId ?? 'root'}`);

  const { items, loadMore, hasMore } = useInfiniteGallery({
    folderId,
    initialItems,
    initialNextCursor,
  });

  React.useEffect(() => {
    if (!hasMore) return;
    const el = document.querySelector('[data-loadmore-trigger]');
    if (!el) return;
    const io = new IntersectionObserver((entries) =>
      entries.forEach((e) => e.isIntersecting && loadMore()),
    );
    io.observe(el);
    return () => io.disconnect();
  }, [hasMore, loadMore]);

  const [selected, setSelected] = React.useState<Record<string, boolean>>({});
  const toggleSelect = (id: string) => setSelected((s) => ({ ...s, [id]: !s[id] }));

  return (
    <>
      <Grid container spacing={2}>
        {items.map((it) => (
          <Grid
            key={it.id}
            sx={{
              xs: 12,
              sm: 6,
              ms: 4,
              lg: 3,
              xl: 2 
            }} 
          >
            <GalleryItemCard
              item={it}
              selected={!!selected[it.id]}
              onToggleSelect={(id) => toggleSelect(id)}
            />
          </Grid>
        ))}
      </Grid>
      <div data-loadmore-trigger style={{ height: 32 }} />
    </>
  );
}
