'use client';
import * as React from 'react';
import { Breadcrumbs, Link as MLink, Typography, Skeleton } from '@mui/material';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { api } from '@/lib/api';

type Crumb = { id: string | null; name: string }; // id:null means root (Gallery)

async function fetchPath(folderId?: string): Promise<Crumb[]> {
  if (!folderId) return [{ id: null, name: 'Gallery' }];
  // EXPECTED backend: GET /api/folder/:id returns ancestors
  // Here we call /api/folder/{id} and expect: { path: [{id,name},...,{id:current,name}] }
  const data = await api<{ path: { id: string; name: string }[] }>(`/api/folder/${folderId}`);
  return [{ id: null, name: 'Gallery' }, ...data.path];
}

export default function BreadcrumbsNav({ compact }: { compact?: boolean }) {
  const sp = useSearchParams();
  const folderId = sp.get('folderId') ?? undefined;

  const { data, status } = useCrumbs(folderId);

  if (status === 'loading') {
    return <Skeleton variant="text" width={240} />;
  }

  const crumbs = data ?? [{ id: null, name: 'Gallery' }];
  const maxItems = compact ? 3 : 8;

  return (
    <Breadcrumbs maxItems={maxItems} itemsBeforeCollapse={1} itemsAfterCollapse={2}>
      {crumbs.slice(0, -1).map((c) =>
        c.id ? (
          <MLink key={c.id} component={Link} href={`/gallery?folderId=${c.id}`}>
            {c.name}
          </MLink>
        ) : (
          <MLink key="root" component={Link} href="/gallery">Gallery</MLink>
        )
      )}
      <Typography color="text.primary">{crumbs[crumbs.length - 1].name}</Typography>
    </Breadcrumbs>
  );
}

// lightweight data hook (no react-query dependency)
function useCrumbs(folderId?: string) {
  const [data, setData] = React.useState<Crumb[] | undefined>(undefined);
  const [status, setStatus] = React.useState<'loading' | 'ready' | 'error'>('loading');

  React.useEffect(() => {
    let alive = true;
    setStatus('loading');
    fetchPath(folderId)
      .then((d) => { if (alive) { setData(d); setStatus('ready'); } })
      .catch(() => { if (alive) setStatus('error'); });
    return () => { alive = false; };
  }, [folderId]);

  return { data, status };
}
