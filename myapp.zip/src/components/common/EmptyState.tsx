'use client';
export default function EmptyState() {
  return <div>Empty — TODO</div>;
}
