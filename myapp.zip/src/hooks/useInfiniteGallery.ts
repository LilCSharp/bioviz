'use client';
import * as React from 'react';
import type { GalleryItem } from '@/lib/types';
import { api } from '@/lib/api';
import { routes } from '@/lib/routes';

export function useInfiniteGallery(opts: {
  folderId?: string;
  initialItems: GalleryItem[];
  initialNextCursor?: string;
}) {
  const [items, setItems] = React.useState<GalleryItem[]>(opts.initialItems);
  const [cursor, setCursor] = React.useState<string | undefined>(opts.initialNextCursor);
  const [loading, setLoading] = React.useState(false);

  const loadMore = React.useCallback(async () => {
    if (!cursor || loading) return;
    setLoading(true);
    const data = await api<{ items: GalleryItem[]; nextCursor?: string }>(
      routes.gallery(opts.folderId) + `&limit=40&cursor=${encodeURIComponent(cursor)}&sort=-date`,
      { cache: 'no-store' },
    );
    setItems((prev) => [...prev, ...data.items]);
    setCursor(data.nextCursor);
    setLoading(false);
  }, [cursor, loading, opts.folderId]);

  return { items, hasMore: Boolean(cursor), loadMore, loading };
}
