'use client';
export function usePersistScroll(key: string) {
  // TODO: save/restore scrollTop per folder
}
